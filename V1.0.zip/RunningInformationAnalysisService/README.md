# Running Information Analysis Service
![][1]  ![][2]  ![][3]  
![][4]

# Step by Step
## 1. Download Code
```bash
git clone 
```

## 2. Start DataBase
### Start MySQL Docker
```
docker-compose up
```
### Login in 
```
mysql --host=127.0.0.1 --port=3306 --user=root --password=root
```

### Init DataBase
```
mysql> show databases;
mysql> create database running_analysis;
mysql> use running_analysis;
```
## 3. Start Server
### Init
```
mvn clean install
cd target
java -jar running-information-analysis-service-1.0.0.BUILD-SNAPSHOT.jar
```
### Post Data
Start PostMan and Post to there
```
http://localhost:9000/create
```

## 4 Feature
### Find All information order by healthWarningLevel
```
http://localhost:9000/findAll
```

### DeleteById
Start PostMan and DELETE

```
http://localhost:9000/delete/{Id}
```
### FindById
```
http://localhost:9000/findId/{runningId}
```
### Show Database
```
mysql> select * from running_analysis;
```
### Find All information
```
http://localhost:9000/runningInformations
```
### findByHeartRateGreaterThan
```
http://localhost:9000/findByHeartRateGreaterThan/{heartRate}
```
### findByTotalRunningTimeGreaterThan
```
http://localhost:9000/findByTotalRunningTimeGreaterThan/{totalRunningTime}
```
## 5. Test Feature

### findByZipcode
```
http://localhost:9000/findByZipcode/{zipcode}
```
### findByState
```
http://localhost:9000/findByState/{state}
```
### Future Work
I try to extract the zipcode (only number) and state from each address, while at this moment I only handle the perfect format about the address like `...., CA 90007`.
But sometime the zipcode can be six digit or with dash in it like `90007-9341` or even with Character like in U.K.
In the future, I will solve this problem and improve the structure of database for theses `state` and `zipcode` are already in `address`.
# Learn
## Linux
```
lsof -i {port} //look up port address
kill -9 {port} //kill the port
```
## Spring
When I try to use findAllOrderByHeartRate this method, it always return issue and cannot complie successfully. So I change my mind to change my code in RestController part using 

```java
Sort sort = new Sort(Sort.Direction.DESC,"heartRate");
```
Another issue is that the result should return in particular order while I try to use `@JsonCreator` and other annotation, it did not work. 
So I try to just create a new `JsonObject` and order by input order. I find `Alibaba.fastjson` can solve this problem
 
```java
JSONObject info = new JSONObject(true);
```
Property expressions

```java
Page<RunningInformation> findByUserInfo_Zipcode;
```
## Reference
1. BitTiger-Master Progrma Backend Engineer -Ross
2. Spring Document [Spring Document](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories.query-methods.query-property-expressions)
3. StackOverFlow and Google



  [1]: https://img.shields.io/badge/SpringBoot-1.3.0-blue.svg
  [2]: https://img.shields.io/badge/alibaba.fastjson-1.2.32-blue.svg
  [3]: https://img.shields.io/badge/lombok-1.16.16-purple.svg
  [4]: https://img.shields.io/badge/hal.browser-2.4.1-green.svg